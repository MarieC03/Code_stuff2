#ifndef MARGHERITA_HELMHOLTZ_CONSTEXPR_HH__
#define MARGHERITA_HELMHOLTZ_CONSTEXPR_HH__
#include <cstdlib> 
namespace margherita { namespace tmpl {
/*
template<size_t N>
static constexpr inline __attribute__((always_inline))
double int_pow(const double& x) { return x * int_pow<N-1>(x) ; }

template<> constexpr inline __attribute__((always_inline))
double int_pow<1>(const double& x) { return x  ; }
*/

template < typename T,
           size_t N >
struct int_pow_impl ; 


template < typename T >
struct int_pow_impl<T,0> {
    constexpr T operator() (T const& x) const { return static_cast<T>(1); }
};

template < typename T,
           size_t N >
struct int_pow_impl {
    constexpr T operator() (T const& x) const { return x * int_pow_impl<T,N-1>()(x);  }
} ; 


template < size_t N,
           typename T >
static constexpr inline __attribute__((always_inline))
T int_pow(const T& x){ return int_pow_impl<T,N>()(x) ; }

}}

#endif 