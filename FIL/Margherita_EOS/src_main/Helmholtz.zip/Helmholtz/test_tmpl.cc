#include "constexpr.hpp"
#include <iostream>
template < int i,
           int j=1,
           typename T >
void print_hello( const T& x ) { std::cout << x << std::endl ; }

int main() { static_assert(margherita::tmpl::int_pow<2>(2) == 4 ); print_hello<1>(2.9); } 