#ifndef MARGHERITA_2D_HERMITE_INTERP_HH__
#define MARGHERITA_2D_HERMITE_INTERP_HH__

#include "hermite.hpp"

#include <memory>
#include <array>

namespace margherita 
{

struct row_major_compressed_index_t ; 

template < typename T,
           size_t num_vars, 
           bool uniform,
           size_t order=5,
           size_t ndim=2 >
struct hermite_interpolator
{
    using compressed_index_t = row_major_compressed_index_t ; 

    using vec_ptr_t = std::unique_ptr<T[]>; 

    static_assert(ndim == 1 || ndim == 2)
    
    
    private: 

    std::array<size_t, ndim> num_points ; 
    std::array<vec_ptr_t, ndim> x ; 

    std::array<T, ndim> dx, idx ;
    
    vec_ptr_t alltables ; 

    public: 
    
    hermite_interpolator() = default ;

    template<typename tab_t, typename ... Xt>
    hermite_interpolator(tab_t && __tab, std::array(size_t, dim) && __n_points, 
                         Xt && ... __x )
    : num_points(std::forward(__n_points)), alltables(std::forward(__tab))
    {
        int n = 0;
        int tmp[] = {(x[n]=std::forward<Xt>(__x), ++n)...} ; 
        (void)tmp ;

        for(size_t idim=0; idim<ndim; ++idim)
        {
            dx[i]  = x[i][1] - x[i][0] ;
            idx[i] = 1./dx[i] ;
        }
    }

    template< 
             size_t ... var_idx, 
             std::pair<size_t, size_t> ... der_var  
             typename ... Xt 
            >
    inline std::array<T, sizeof...(var_idx)>
    interpolate (Xt const & ... x) const
    {
        int dir = -1 ;
        auto const index = 
             std::array<size_t, ndim>{(++dir, find_index(dir,xin))...} ; 
        return std::array<T, sizeof...(vars)> 
        { ( interpolate_single<compressed_index_t, var_idx, Xt...>(index, xin...))... };
    } 
}

}

#endif 