#ifndef MARGHERITA_HERMITE_5_HH__
#define MARGHERITA_HERMITE_5_HH__


#include <cstdlib>
#include "constexpr.hpp"

namespace margherita {

/*
* Hermite basis functions
*/ 
template< typename T,
          size_t order,
          size_t n,
          size_t der_ord > 
struct herm_psi_impl ; 


template<typename T> 
struct herm_psi_impl<T, 5, 0, 0>
{
    constexpr T operator() (const T& x) const
    {
        return -6. * tmpl::int_pow<5>(x) + 15. * tmpl::int_pow<4>(x) - 10. * tmpl::int_pow<3>(x) + 1. ;
    }
}; 

template<typename T> 
struct herm_psi_impl<T, 5, 1, 0>
{
    constexpr T operator() (const T& x) const
    {
        return -3. * tmpl::int_pow<5>(x) + 8. * tmpl::int_pow<4>(x) - 6. * tmpl::int_pow<3>(x) + x ;
    }
}; 

template<typename T> 
struct herm_psi_impl<T, 5, 2, 0>
{
    constexpr T operator() (const T& x) const
    {
        return 0.5*(-tmpl::int_pow<5>(x) + 3. * tmpl::int_pow<4>(x) - 3. * tmpl::int_pow<3>(x) + tmpl::int_pow<2>(x)) ;
    }

};



template<typename T> 
struct herm_psi_impl<T, 5, 0, 1>
{
    constexpr T operator() (const T& x) const
    {
        return -30. * tmpl::int_pow<4>(x) + 60. * tmpl::int_pow<3>(x) - 30. * tmpl::int_pow<2>(x) ;
    }
}; 

template<typename T> 
struct herm_psi_impl<T, 5, 1, 1>
{
    constexpr T operator() (const T& x) const
    {
        return -15. * tmpl::int_pow<4>(x) + 32. * tmpl::int_pow<3>(x) - 9. * tmpl::int_pow<2>(x) + 1. ;
    }
}; 

template<typename T> 
struct herm_psi_impl<T, 5, 2, 1>
{
    constexpr T operator() (const T& x) const
    {
        return 0.5*(-5.*tmpl::int_pow<4>(x) + 12. * tmpl::int_pow<3>(x) - 9. * tmpl::int_pow<2>(x) + 2.*x) ;
    }

};

// second derivatives 
template<typename T> 
struct herm_psi_impl<T, 5, 0, 2>
{
    constexpr T operator() (const T& x) const
    {
        return x * ( x * (-120. * x + 180. ) - 60. )  ;
    }
}; 

template<typename T> 
struct herm_psi_impl<T, 5, 1, 2>
{
    constexpr T operator() (const T& x) const
    {
        return x * ( x * (-60. * x + 96. ) - 36. ) + 1. ;
    }
}; 

template<typename T> 
struct herm_psi_impl<T, 5, 2, 2>
{
    constexpr T operator() (const T& x) const
    {
        return 0.5*( x * ( x * ( -20*x + 36. ) - 18. ) + 2.) ;
    }

};

// interface 
template <  
          size_t ord,
          size_t n,
          size_t der_ord=0,
          typename T
         >
static constexpr inline __attribute__((always_inline))
T herm_psi(const T& x) { return herm_psi_impl<T,ord,der_ord,n>()(x) ; }


}

#endif 